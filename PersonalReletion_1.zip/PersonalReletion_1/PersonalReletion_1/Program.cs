﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PersonalReletion_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Person person1 = new Person();
            Person person2 = new Person();
            Person person3 = new Person();
            Person person4 = new Person();
            Person person5 = new Person();
            Person person6 = new Person();
            Person[] personArray = new Person[6];
            Utility util = new Utility();

            person1.FullName.FirstName = "Alex";
            person1.FullName.LastName = "Finkelshtein";
            person1.Address.City = "Holon";
            person1.Address.Street = "Sokolov";

            person2.FullName.FirstName = "Dani";
            person2.FullName.LastName = "Levi";
            person2.Address.City = "Holon";
            person2.Address.Street = "Sokolov";

            person3.FullName.FirstName = "Dani";
            person3.FullName.LastName = "Levi";
            person3.Address.City = "Tel Aviv";
            person3.Address.Street = "Alenbi";

            person4.FullName.FirstName = "Omer";
            person4.FullName.LastName = "Adam";
            person4.Address.City = "Tel Aviv";
            person4.Address.Street = "Alenbi";

            person5.FullName.FirstName = "Omer";
            person5.FullName.LastName = "Adam";
            person5.Address.City = "Yavne";
            person5.Address.Street = "Gefen";

            person6.FullName.FirstName = "omer";
            person6.FullName.LastName = "Adam";
            person6.Address.City = "yavne";
            person6.Address.Street = "Gefen";

            personArray[0] = person1;
            personArray[1] = person2;
            personArray[2] = person3;
            personArray[3] = person4;
            personArray[4] = person5;
            personArray[5] = person6;

            util.Init(personArray);


            //print person array details
            for (int i = 0; i < personArray.Length; i++)
            {
                Console.WriteLine("Person {0}", i + 1 + " : "  + personArray[i].FullName.FirstName + " " + personArray[i].FullName.LastName);
                Console.WriteLine("your address is : " + personArray[i].Address.City + " " + personArray[i].Address.Street);
            }



            //relation print
            Console.WriteLine("Relation between person {0} and person {1} is : {2} ", 1, 2, util.findMinRelation(person1, person2));
            Console.WriteLine("Relation between person {0} and person {1} is : {2} ", 1, 3, util.findMinRelation(person1, person3));
            Console.WriteLine("Relation between person {0} and person {1} is : {2} ", 1, 4, util.findMinRelation(person1, person4));
            Console.WriteLine("Relation between person {0} and person {1} is : {2} ", 5, 1, util.findMinRelation(person5, person1));
            Console.WriteLine("Relation between person {0} and person {1} is : {2} ", 3, 1, util.findMinRelation(person3, person1));
            Console.WriteLine("Relation between person {0} and person {1} is : {2} ", 4, 1, util.findMinRelation(person4, person1));
            Console.WriteLine("Relation between person {0} and person {1} is : {2} ", 1, 5, util.findMinRelation(person1, person5));
            Console.WriteLine("Relation between person {0} and person {1} is : {2} ", 1, 6, util.findMinRelation(person1, person6));
            Console.WriteLine("Relation between person {0} and person {1} is : {2} ", 3, 6, util.findMinRelation(person3, person6));
            Console.WriteLine("Relation between person {0} and person {1} is : {2} ", 6, 4, util.findMinRelation(person6, person4));
            Console.WriteLine("Relation between person {0} and person {1} is : {2} ", 6, 6, util.findMinRelation(person6, person6));

            
            Console.ReadLine();
        }
    }

    class Person
    {
        public Name FullName = new Name();
        public Address Address = new Address();
    }
    class Name
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
    class Address
    {
        public string Street { get; set; }
        public string City { get; set; }
    }



    class Utility
    {
        private Person[] personArray;
        int resultRec = 0;
   //     int result = 0;
        List<Person> visitedCandidate = new List<Person>();

        //init array of persons 
        public void Init(Person[] p)
        {
            personArray = new Person[p.Length];
            for (int i = 0; i < p.Length; i++)
            {
                personArray[i] = p[i];
            }
            
        }

        //find the minimum relation between person two persons
        public int findMinRelation(Person p1, Person p2)
        {
            int result = 0;
            int min = personArray.Length;
 
                if (p1.FullName.FirstName == p2.FullName.FirstName && p1.FullName.LastName == p2.FullName.LastName
                 || p1.Address.City == p2.Address.City && p1.Address.Street == p2.Address.Street)
                {
                    result += 1;
                    result += resultRec;
                }
                else if (resultRec < personArray.Length)
                {
                    resultRec++;
                    List<Person> nextCandidate = new List<Person>();
                    
                    nextCandidate = findNextPerson(p1);
                    visitedCandidate.Add(p1);

                    foreach (Person p in visitedCandidate)
                    {
                        nextCandidate.Remove(p);
                    }

                    foreach (Person p in nextCandidate)
                    {   
                        int min1 = findMinRelation(p, p2);
                        if (min1 <= min)
                        {
                            min = min1;
                            result = min1;
                        }
                    }

                }
                if (result == 0)
                {
                   result = -1;
                }

                resultRec = 0;
       //         result = 0;
                visitedCandidate.Clear();
                return result;
        }

        //return list of persons with relation 1 to person p1
        private List<Person> findNextPerson(Person p1)
        {
            List<Person> relatedPerson = new List<Person>();
            for(int i = 0; i < personArray.Length; i++)
            {
                if (p1.FullName.FirstName == personArray[i].FullName.FirstName && p1.FullName.LastName == personArray[i].FullName.LastName
                || p1.Address.City == personArray[i].Address.City && p1.Address.Street == personArray[i].Address.Street)
                { 
                    relatedPerson.Add(personArray[i]); 
                }
            }
            return relatedPerson;
        }

    }

}
